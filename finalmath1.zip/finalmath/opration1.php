<!DOCTYPE html>
<html lang="en">
<head>
  <title>Select Options</title>
  <meta charset="utf-8">
</head>

<style>

.zoom{
  transition: transform 0.4s;
}
.zoom:hover{
  transform:scale(1.2);
}
.card{
  width: 230px;
  height: :80px;
    border-radius: 30px;
    box-shadow: 2px 2px 1.5px 1.5px;
    font-family: 'Baloo Bhai', cursive;
}
.card:hover{
     box-shadow: 1px 1px 1px 1px #336599;
}\
</style>

<body>
  <?php
  session_start();
$name=$_SESSION['User'];


   ?>
   <?php include("rnav.php");
   ?>


  <div class="container-fluid" style="margin-top:100px">
    <br>
    <h1 style="text-align:center;font-family: 'Metal Mania';font-size: 30px;" class="mt-2"><b>Category</b> </h1>
 <div class="container " style="" >
    <div class='row'>

     <?php
 $id=$_GET['gid'];



//$conn=mysqli_connect("localhost","root","","quiz");
include('config.php');
$sql="select * from category where Grade_id=$id";

$res=mysqli_query($con,$sql);
if($res==True){
$i=1;
while($record=mysqli_fetch_assoc($res)){
$cid=$record['cid'];
$cname=$record['category'];
$img=$record['image'];
  $path = "math/admin/queimg/$img";
  //echo "$path";
    echo"<div class='col-lg-3 pt-4 '>";
      echo"<div class='card' >";
    echo  "<center> <a href='rule.php?cid=$cid & gid=$id'>  <div class='card-image waves-effect waves-block waves-light ' style='width:200px;'>";
echo " <img class='activator mt-4' src='$path' height='150px' width='200px'></a>";
  echo"</div></a></center>";
       echo"<center><div class='card-content'>";
      echo  " <span class='card-title activator 'style='font-family:serif;font-size:25px;color:#E60576'><b>$cname</b></span>";
    echo  " </div></center>";
    echo "</div>";
echo"</div>";
$i++;
}
}
 ?>
 </div>
</div>
<div class="container-fluid" style="margin-top:20px;">
  <a href="Homepage.php"><button type="Go Back" style="margin-left:1090px;" class="btn btn-primary btn-lg"><b>GO Back</b></button></a>
  <img class="img-fluid f1-image mb-5" src="images/math-footer-1920.png" style="height:300px;">

</div>
<!--
<div class="container-fluid mt-3">
  <div class="col-lg-12">
  <div class="row">
    <div class="">
      <img class="img-fluid f1-image" src="images/math-footer-1920.png" style="height:350px;">
    </div>
  </div>
</div>
</div>-->

</body>
</html>
