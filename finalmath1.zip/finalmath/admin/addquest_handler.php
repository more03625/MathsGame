<?php
$conn= mysqli_connect("localhost","riya","riya123","MathsGame");
 if ($conn->connect_error) {
   die("Connection failed:" .$conn->connect_error);
   }
  else {
       echo "connection ok";
   }

   $quest=$_POST['quest'];
   $Grade=$_POST['Grade'];
   $Operation=$_POST['cid'];
   $Ans=$_POST['Ans'];
   $opt1=$_POST['opt1'];
   $opt2=$_POST['opt2'];
   $opt3=$_POST['opt3'];
   $opt4=$_POST['opt4'];
   $img=$_FILES['img'];

   $query=mysqli_query($conn,"select max(id) as id from question");
$result=mysqli_fetch_array($query);
$qid=$result['id']+1;
$dir="queimg/$qid";
if(!is_dir($dir)){
  mkdir("queimg/".$qid,0777);
}
move_uploaded_file($_FILES["img"]["tmp_name"],"queimg/$qid/".$_FILES["op1"]["name"]);

   $sql ="INSERT INTO Questions(Questions,Grade_id,cid,Correct_ans,opt1,opt2,opt3,opt4,images)
    VALUES('$quest','$Grade','$Operation','$Ans','$opt1','$opt2','$opt3','$opt4','$img')";


    if ($conn->query($sql) === TRUE) {
       echo "<script>alert('New Record Created Successfully');
             window.location.href='Admin.php';
           </script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

   $conn->close();


?>
