<!DOCTYPE html>
<html lang="en">
   <head>
      <title>Question</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
   </head>
   <body>
      <div class="container m-1 pr-5">
         <div class="row">
            <h4>Add Question</h4>

            <form action="addquest_handler.php" method="post">
               <div class="form-group">
                  <label for="Question"></label>
                  <input type="text" class="form-control" placeholder="Question" name="quest" required>
               </div>
               <div class="form-inline">
                  <h5>Operations:&nbsp &nbsp</h5>


<div class="">

<div class="select" type="text">
  <select class="form-control" value="1" name="Operation">
    <Option value="">1</option>
      <Option value="">2</option>
        <Option value="">3</option>
          <Option value="">4</option>
          </select>

</div>

</div>              &nbsp&nbsp&nbsp &nbsp &nbsp
                  <h5>Grade:&nbsp &nbsp</h5>
               <input type="text" class="form-control" placeholder="Grade" name="Grade" required>
               </div>
               </br>
               <div class="form-group">
                  Select image to upload:
                  <input type="file" name="img" value="Upload Image">
                  </br></br>
               </div>
               <h4 class="">Answer Options</h4>
               <div class="form-inline">
                  </br></br>
                  <input type="text" class="form-control m-1" placeholder="Option 1" name="opt1" required>
                  <input type="text" class="form-control m-1" placeholder="Option 2" name="opt2" required>
                  <input type="text" class="form-control m-1" placeholder="Option 3" name="opt3" required>
                  <input type="text" class="form-control m-1" placeholder="Option 4" name="opt4" required>
               </div>
               <br>
               <h3 class="">
               <b>Correct Answers</b>
               <h3>
               <div class="form-group">
                  <input type="text" class="form-control" placeholder="Answer" name="Ans" required>
                  <br>
                  <button type="submit" class="btn btn-info"> Add Question </button>
            </form>
            </div>
         </div>
      </div>
      </center>
   </body>
</html>
