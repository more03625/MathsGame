<div class=" container-fluid hh">
  <br>
  <h1 style="text-align:center;font-family: 'Metal Mania';font-size: 40px;" class="mt-2">Category </h1>
<div class="container " style="" >
  <div class='row'>

   <?php
$id=$_GET['aid'];



//$conn=mysqli_connect("localhost","root","","quiz");
include('config.php');
$sql="select * from category where age_id=$id";

$res=mysqli_query($con,$sql);
if($res==True){
$i=1;
while($record=mysqli_fetch_assoc($res)){
$cid=$record['cid'];
$cname=$record['category'];
$img=$record['cimage'];

  echo"<div class='col-lg-3 pt-4 '>";
    echo"<div class='card' >";
  echo  "<center> <a href='rule.php?cid=$cid & aid=$id'>  <div class='card-image waves-effect waves-block waves-light ' style='width:200px;'>";
echo  " <img class='activator mt-4' src='admin/categoryimages/$cid/$img' height='200px' width='200px'></a>";
echo"</div></a></center>";
     echo"<center><div class='card-content'>";
    echo  " <span class='card-title activator 'style='font-family:serif;font-size:40px;color:#E60576'><b>$cname</b></span>";
  echo  " </div></center>";
  echo "</div>";
echo"</div>";
$i++;
}
}
?>
</div>
</div>
