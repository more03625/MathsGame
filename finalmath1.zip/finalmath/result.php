<?php
 session_start();
?>
<?php

//$con=mysqli_connect("localhost","root","","quiz");
include('config.php');
if(!empty($_SESSION['User'])){

    $right_answer=0;
    $wrong_answer=0;
    $unanswered=0;

   $keys=array_keys($_POST);
   $order=join(",",$keys);

   //$query="select * from questions id IN($order) ORDER BY FIELD(id,$order)";
  // echo $query;exit;

   $response=mysqli_query($con, "select id,correct_ans from question where id IN($order) ORDER BY FIELD(id,$order)")   or die(mysqli_error());
   // print_r($response);
   // die();

   while($result=mysqli_fetch_array($response)){
       if($result['correct_ans']==$_POST[$result['id']]){

               $right_answer++;
           }else if($_POST[$result['id']]==5){
               $unanswered++;
           }
           else{
               $wrong_answer++;
           }
   }
   $name=$_SESSION['User'];
   mysqli_query( $con, "update users set user_score='$right_answer' where user_name='$name'");

?>
<!DOCTYPE html>
<html>
    <head>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>

        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- Bootstrap -->
        <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="css/style.css" rel="stylesheet" media="screen">
        <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!--[if lt IE 9]>
        <script src="../../assets/js/html5shiv.js"></script>
        <script src="../../assets/js/respond.min.js"></script>
        <![endif]-->

    </head>
    <body>
      <?php include("indexnav.php"); ?>


      <!-- <nav class="navbar navbar-light container-fluid sticky-top" style=" background: linear-gradient(to right, #ffffff 17%, #ffccff 100%);">
        <div class="col-lg-3 col-4">
          <a class="navbar-brand" href="index.php">
            <img src="Images/1520320708piflogo.png" class="img-fluid mb-1" alt="">
          </a>
        </div>
        <div class="col-lg-3 col-5">
            <h1 class="align-bottom pl-2" style="font-size:5vw;font-family: 'Metal Mania', cursive;color:yellowgreen">Quiz<span style="font-family: 'Metal Mania', cursive;color:blue;font-size:3vw;">Time</span></h1>
        </div>
        <div class="col-lg-2 col-3" >
          <form class="form-colntrol" action="logout.php" method="post"> -->
                  <?php

                                    // error_reporting(0);
                                    // if (strlen($_SESSION['user_id'])>0) {
                                    //   echo "<a href='logout.php' class='btn btn-lg' style='background-color:yellowgreen;font-family: 'Metal Mania';'>Logout</a>";
                                    // } else {
                                    //     echo "<input type='submit' class='btn ' style='margin-left:13vw;' name='logout' value='Logout'>";
                                    // }
                                     ?>
                                   <!-- </form> -->
          <!-- <a href="logout.php" class="btn" style="background-color:yellowgreen;font-family: 'Metal Mania';">Logout</a> -->
        <!-- </div> -->

      <!-- </nav> -->




        <div class="container result" style="margin-top:140px;">
            <div class="row">
                    <div class='result-logo'>

                    </div>
           </div>

           <div class="container-fluid">
             <div class="row">
             <div class="col-lg-6">
               <div>

                 <canvas id="doughnutChart" style="max-width: 300px;"></canvas>
               </div>
             </div>

                  <div class="col-lg-6" style="font-family:'Metal Mania';font-size: 20px;text-align:center">


                       <div style="mt-5">
                        <p>Total no. of right answers : <span class="answer"><?php echo $right_answer;?></span></p>
                        <p>Total no. of wrong answers : <span class="answer" style="color:red;"><?php echo $wrong_answer;?></span></p>
                        <p>Total no. of Unanswered Questions : <span class="answer"style="color:blue;"><?php echo $unanswered;?></span></p><br>
                       </div>
                       <a href="opration1.php?gid=1" class='btn btn-lg ' style="font-size:20px;color:black;background-color:yellowgreen">Start new Quiz!!!</a>
                   </div>
                 </div>


            </div>
            <div class="container-fluid">
              <img class="img-fluid f1-image mb-5" src="images/math-footer-1920.png" style="height:250px; width:1300px">

            </div>
        </div>
      <?php //include('footer.php'); ?>
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery-1.10.2.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="js/jquery.validate.min.js"></script>




        <script>
        var mypie= document.getElementById("doughnutChart").getContext('2d');
        var myPieChart = new Chart(mypie,{
          type: 'doughnut',
          data: {
            labels: ["Unanswer", "Correct Answer", "Wrong Answer"],
            datasets:
            [{
              data: [<?php echo $unanswered;?>,<?php echo $right_answer;?>,<?php echo $wrong_answer;?>],
              backgroundColor: ["#F7464A", "#46BFBD", "#FDB45C"],
              hoverBackgroundColor: ["#FF5A5E", "#5AD3D1", "#FFC870"]
            }]
          },
          options: {
            responsive: true
          }
        });
      </script>

    </body>
</html>

<!-- <?php //}else{

 //header( 'Location: http://localhost/quiztwo/index.php' ) ;

}?> -->
