<!DOCTYPE html>
<html>
<head>
<style>
.button {
  width: 200px;
  height: :300px;
}



.button1 {
  background-color: white;
  color: black;
  border: 2px solid  #4CAF50;
}

.button1:hover {
  background-color: blue;
  color: white;
  text-color:white;
}

a:hover {
 box-shadow: 3px 2px 4px rgba(.5, .5, .5, .5);
}

.container1-fluid{

}

.f1-image {
    position: absolute;
    width: 100;
    height: 398px;

    /* top: 50%;
    left: 50%; */
}
</style>
<title>HomePage | MATHS GAME</title>
</head>
<body>
  <?php
  session_start();
$name=$_SESSION['User'];


   ?>
  <?php include("indexnav.php");
  ?>


  <div class="container-fluid" style="margin-top:50px;">
<div class="col-lg-12">
  <div class="row">









<?php
$con = mysqli_connect("localhost","phpmyadmin","krutika123");
mysqli_select_db($con,"quiz2");


  $sql="select * from Grade";
  $res=mysqli_query($con,$sql);
  if($res==True){
    $i=1;
    while($record=mysqli_fetch_assoc($res)){
$gid=$record['Grade_id'];
      $grade=$record['Grade_name'];
    ?>
      <div class="col-lg-3 pt-3" style="border-radius:30px">

        <a class="container-fluid"  href="login.php?gid=<?php echo $gid; ?>"style="text-decoration:none">
        <!--<div class="card" >-->
          <div class="container" >
<center><button type="button" class="button button1 p-5 mt-5 rounded" ><h4><?php echo $grade; ?></h4></button></a><center>
          </div>


        <!--</div>--></a>
      </div>


      <?php
$i++;
    }
  }

  else{

    echo"connection error";
  }

   ?>
</div>
</div>
</div>
<div class="container-fluid mt-5">
  <div class="row">
    <div class="">
      <img class="img-fluid f1-image" src="images/Homepageback.jpg" style="height:300px;">
    </div>
  </div>
</div>


</body>
</html>
