<?php
session_start();
//$count = 0;
$name=$_SESSION['name'];

if(!isset($_SESSION['name'])){


  header('Location: login.php');
}
?>
<?php
//$con=mysqli_connect("localhost","root","","quiz");
include('config.php');
$category1='';

$category=$_GET['lid'];



$aid=$_GET['gid'];

 if(!empty($_POST['name'])){
     $name=$_POST['name'];
      $category=$_POST['category'];
    // mysqli_query( $con, "INSERT INTO users (id,user_name,user_score,cid)VALUES (null,'$name',0,'$category')") or die(mysqli_error());
    $_SESSION['name']= $name;

    $_SESSION['id'] = mysqli_insert_id();
//  echo "New record has id: " . mysqli_insert_id($con);
  }

if(!empty($_SESSION['name'])){
  include('config.php');
  $name=$_SESSION['name'];

  $cat=$_GET['lid'];
  $score=0;
  $sql1="insert into score values(null,'$cat','$name',$score)";

  $result1=mysqli_query($con,$sql1);
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="https://fonts.googleapis.com/css?family=Metal+Mania&display=swap" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet" media="screen">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
<script src="../../assets/js/html5shiv.js"></script>
<script src="../../assets/js/respond.min.js"></script>
<![endif]-->

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery-1.10.2.min.js"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.validate.min.js"></script>
<script src="js/countdown.js"></script>
<style>
.container {
/* margin-top: 110px; */
}
      html{
        overflow-x:hidden;
      }
.error {
color: #B94A48;
}
.form-horizontal {
margin-bottom: 0px;
}
.hide{display: none;}
      .question{
       font-family: 'Metal Maria';
       font-size:30px;
       font-weight: bold;
      }
      input[type=radio] {
    border: 2px;
    width: 7%;
    height: 3vh;
}
.collapsible {
  background-color: yellowgreen;
  color: black;
  cursor: pointer;
  padding:1vh;
  width: 18%;
  border: none;
  text-align: center;
  outline: none;
  font-size: 3vh;

  float:right;
}

.active, .collapsible:hover {
  background-color:yellowgreen;
}

.content {
  padding: 0 18px;
  display: none;
  overflow: hidden;
  background-color: #f1f1f1;
  color:blue;
}

</style>
</head>
<body>
  <?php
include('header.php');
   ?>
<div class="container">

  <div class="row">
    <div class="col-lg-5">

    </div>
    <div class="col-lg-5">

    </div>
    <div class="col-lg-2">
      <div class="container" id='timer'>
          <script type="application/javascript">
          var myCountdownTest = new Countdown({
                                  time: 120,
                                  width:200,
                                  height:80,
                                  rangeHi:"minute"
                                  });
         </script>

      </div>
    </div>

  </div>
</div><br>

<div class="container question">
      <div class="row">
<div class="col-xs-12 col-sm-8 col-md-8 col-xs-offset-4 col-sm-offset-3 col-md-offset-3 col-12">
<form class="form-horizontal" role="form" id='login' method="post" action="result1.php">
<?php
$number_question = 1;
$row = mysqli_query( $con, "select * from question where lid=$category ");
$rowcount = mysqli_num_rows( $row );
$remainder = $rowcount/$number_question;
$i = 0;
$j = 1; $k = 1;
?>
<?php while ( $result = mysqli_fetch_assoc($row) ) {
            $id=$result['id'];
              $op1=$result['opt1'];
                $op2=$result['opt2'];
                $op3=$result['opt3'];
                $op4=$result['opt4'];
                $op4=$result['opt5'];
                $op4=$result['opt6'];
                $op4=$result['opt7'];
                echo "<div class='container col-lg-12 col-12'>";
if ( $i == 0) echo "<div class='cont' id='question_splitter_$j'>";?>

<div class="container" id='question<?php echo $k;?>' >

            <p class='questions' style="margin-left:200px; margin-top:-17px;"  id="qname<?php echo $j;?>"> <?php echo $k?>.&nbsp;&nbsp;&nbsp;<?php echo $result['que_name'];?></p>
<img src="admin/queimg/<?php echo $result['img'];?>"width="47%"style="height:200px; border:2px solid ; margin-left:270px;" alt="">

            <?php

if($aid==1 and $category==1){

  ?>

  <input type="text" name="qid[]"  style="width:100px; height:100px; margin-left:270px; margin-top:30px; text-align:center;" value="<?php echo $result['id'];?>" hidden id='text_<?php echo $result['id'];?>' />
  <input type="text" name="<?php echo $result['id'];?>.opt1"  style="width:100px; height:100px; margin-left:270px; margin-top:30px; text-align:center;" value=""  id='text_<?php echo $result['id'];?>' />
    <input type="text" name="<?php echo $result['id'];?>.opt2" style="width:100px; height:100px; text-align:center;" value="<?php echo $result['opt2'] ?>"  id='text_<?php echo $result['id'];?>' />
      <input type="text" name="<?php echo $result['id'];?>.opt3" style="width:100px; height:100px; text-align:center;" value="<?php echo $result['opt3'] ?>"  id='text_<?php echo $result['id'];?>'/>

  <input type="radio" checked='checked' style='display:none' value="5" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>


<?php
}
if($aid==1 and $category==2){

  ?>
  <input type="text" name="qid[]"  style="width:80px; height:80px; margin-left:260px; margin-top:30px; text-align:center;" value="<?php echo $result['id'];?>" hidden id='text_<?php echo $result['id'];?>' />
  <!-- <input type="text" style="width:80px;text-transform:uppercase; height:80px; margin-left:260px; margin-top:30px; text-align:center;" value="" name='<?php echo $result['id'];?>' id='radio1_<?php echo $result['id'];?>' /> -->
    <input type="text" style="margin-left:260px; margin-top:30px; width:80px; height:80px;text-transform:uppercase; text-align:center;" value="<?php echo $result['opt1'] ?>"  name="<?php echo $result['id'];?>_opt1" id='radio1_<?php echo $result['id'];?>' />
      <input type="text" style="width:80px; height:80px;text-transform:uppercase; text-align:center;" value=""  name="<?php echo $result['id'];?>.opt2" id='radio1_<?php echo $result['id'];?>'/>
      <input type="text" style="width:80px; height:80px;text-transform:uppercase; text-align:center;" value="<?php echo $result['opt3'] ?>"  name="<?php echo $result['id'];?>_opt3" id='radio1_<?php echo $result['id'];?>'/>
      <input type="text" style="width:80px; height:80px;text-transform:uppercase; text-align:center;" value="<?php echo $result['opt4'] ?>"  name="<?php echo $result['id'];?>_opt4" id='radio1_<?php echo $result['id'];?>'/>

  <input type="radio" checked='checked' style='display:none' value="5" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>


<?php
}
if($aid==1 and $category==3){

  ?>

  <input type="text" name="qid[]"  style="width:100px; height:100px; margin-left:270px; margin-top:30px; text-align:center;" value="<?php echo $result['id'];?>" hidden id='text_<?php echo $result['id'];?>' />
  <input type="text" name="<?php echo $result['id'];?>.opt1"  style="width:60px; height:60px; margin-left:260px; margin-top:30px; text-align:center;" value=""  id='text_<?php echo $result['id'];?>' />
    <input type="text" name="<?php echo $result['id'];?>.opt2" style="width:60px; height:60px; text-align:center;" value="<?php echo $result['opt2'] ?>"  id='text_<?php echo $result['id'];?>' />
      <input type="text" name="<?php echo $result['id'];?>.opt3" style="width:60px; height:60px; text-align:center;" value=""  id='text_<?php echo $result['id'];?>'/>
      <input type="text" name="<?php echo $result['id'];?>.opt4" style="width:60px; height:60px; text-align:center;" value="<?php echo $result['opt4'] ?>"  id='text_<?php echo $result['id'];?>'/>
      <input type="text" name="<?php echo $result['id'];?>.op5" style="width:60px; height:60px; text-align:center;" value="<?php echo $result['op5'] ?>"  id='text_<?php echo $result['id'];?>'/>


  <input type="radio" checked='checked' style='display:none' value="5" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>


<?php
}

if($aid==2 and $category==5){

  ?>

  <input type="text" name="qid[]"  style="width:100px; height:100px; margin-left:270px; margin-top:30px; text-align:center;" value="<?php echo $result['id'];?>" hidden id='text_<?php echo $result['id'];?>' />
  <input type="text" name="<?php echo $result['id'];?>.opt1"  style="width:80px; height:80px; margin-left:270px; margin-top:30px; text-align:center;" value=""  id='text_<?php echo $result['id'];?>' />
    <input type="text" name="<?php echo $result['id'];?>.opt2" style="width:80px; height:80px; text-align:center;" value="<?php echo $result['opt2'] ?>"  id='text_<?php echo $result['id'];?>' />
      <input type="text" name="<?php echo $result['id'];?>.opt3" style="width:80px; height:80px; text-align:center;" value=""  id='text_<?php echo $result['id'];?>'/>
      <input type="text" name="<?php echo $result['id'];?>.opt4" style="width:80px; height:80px; text-align:center;" value="<?php echo $result['opt4'] ?>"  id='text_<?php echo $result['id'];?>'/>



<?php
}
if($aid==2 and $category==6){

  ?>

  <input type="text" name="qid[]"  style="width:100px; height:100px; margin-left:270px; margin-top:30px; text-align:center;" value="<?php echo $result['id'];?>" hidden id='text_<?php echo $result['id'];?>' />
  <input type="text" name="<?php echo $result['id'];?>.opt1"  style="width:60px; height:60px; margin-left:270px; margin-top:30px; text-align:center;" value=""  id='text_<?php echo $result['id'];?>' />
    <input type="text" name="<?php echo $result['id'];?>.opt2" style="width:60px; height:60px; text-align:center;" value="<?php echo $result['opt2'] ?>"  id='text_<?php echo $result['id'];?>' />
      <input type="text" name="<?php echo $result['id'];?>.opt3" style="width:60px; height:60px; text-align:center;" value=""  id='text_<?php echo $result['id'];?>'/>
      <input type="text" name="<?php echo $result['id'];?>.opt4" style="width:60px; height:60px; text-align:center;" value="<?php echo $result['opt4'] ?>"  id='text_<?php echo $result['id'];?>'/>
      <input type="text" name="<?php echo $result['id'];?>.op5" style="width:60px; height:60px; text-align:center;" value="<?php echo $result['op5'] ?>"  id='text_<?php echo $result['id'];?>'/>

  <input type="radio" checked='checked' style='display:none' value="5" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>


<?php
}
if($aid==2 and $category==7){

  ?>

  <input type="text" name="qid[]"  style="width:100px; height:100px; margin-left:270px; margin-top:30px; text-align:center;" value="<?php echo $result['id'];?>" hidden id='text_<?php echo $result['id'];?>' />
  <input type="text" name="<?php echo $result['id'];?>.opt1"  style="width:40px; height:40px; margin-left:270px; margin-top:30px; text-align:center;" value=""  id='text_<?php echo $result['id'];?>' />
    <input type="text" name="<?php echo $result['id'];?>.opt2" style="width:40px; height:40px; text-align:center;" value="<?php echo $result['opt2'] ?>"  id='text_<?php echo $result['id'];?>' />
      <input type="text" name="<?php echo $result['id'];?>.opt3" style="width:60px; height:60px; text-align:center;" value=""  id='text_<?php echo $result['id'];?>'/>
      <input type="text" name="<?php echo $result['id'];?>.opt4" style="width:60px; height:60px; text-align:center;" value="<?php echo $result['opt4'] ?>"  id='text_<?php echo $result['id'];?>'/>
      <input type="text" name="<?php echo $result['id'];?>.op5" style="width:60px; height:60px; text-align:center;" value=""  id='text_<?php echo $result['id'];?>'/>
      <input type="text" name="<?php echo $result['id'];?>.op6" style="width:60px; height:60px; text-align:center;" value="<?php echo $result['op6'] ?>"  id='text_<?php echo $result['id'];?>'/>

  <input type="radio" checked='checked' style='display:none' value="5" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>


<?php
}
if($aid==3 and $category==8){
?>

<input type="text" name="qid[]"  style="width:100px; height:100px; margin-left:270px; margin-top:30px; text-align:center;" value="<?php echo $result['id'];?>" hidden id='text_<?php echo $result['id'];?>' />
<input type="text" name="<?php echo $result['id'];?>.opt1"  style="width:60px; height:60px; margin-left:270px; margin-top:30px; text-align:center;" value=""  id='text_<?php echo $result['id'];?>' />
  <input type="text" name="<?php echo $result['id'];?>.opt2" style="width:60px; height:60px; text-align:center;" value="<?php echo $result['opt2'] ?>"  id='text_<?php echo $result['id'];?>' />
    <input type="text" name="<?php echo $result['id'];?>.opt3" style="width:60px; height:60px; text-align:center;" value=""  id='text_<?php echo $result['id'];?>'/>
    <input type="text" name="<?php echo $result['id'];?>.opt4" style="width:60px; height:60px; text-align:center;" value="<?php echo $result['opt4'] ?>"  id='text_<?php echo $result['id'];?>'/>
    <input type="text" name="<?php echo $result['id'];?>.op5" style="width:60px; height:60px; text-align:center;" value="<?php echo $result['op5'] ?>"  id='text_<?php echo $result['id'];?>'/>

<?php
}
if($aid==3 and $category==9){
 ?>

 <input type="text" name="qid[]"  style="width:100px; height:100px; margin-left:270px; margin-top:30px; text-align:center;" value="<?php echo $result['id'];?>" hidden id='text_<?php echo $result['id'];?>' />
 <input type="text" name="<?php echo $result['id'];?>.opt1"  style="width:50px; height:50px; margin-left:270px; margin-top:30px; text-align:center;" value=""  id='text_<?php echo $result['id'];?>' />
   <input type="text" name="<?php echo $result['id'];?>.opt2" style="width:50px; height:50px; text-align:center;" value="<?php echo $result['opt2'] ?>"  id='text_<?php echo $result['id'];?>' />
     <input type="text" name="<?php echo $result['id'];?>.opt3" style="width:50px; height:50px; text-align:center;" value=""  id='text_<?php echo $result['id'];?>'/>
     <input type="text" name="<?php echo $result['id'];?>.opt4" style="width:50px; height:50px; text-align:center;" value="<?php echo $result['opt4'] ?>"  id='text_<?php echo $result['id'];?>'/>
     <input type="text" name="<?php echo $result['id'];?>.op5" style="width:50px; height:50px; text-align:center;" value=""  id='text_<?php echo $result['id'];?>'/>
     <input type="text" name="<?php echo $result['id'];?>.op6" style="width:50px; height:50px; text-align:center;" value="<?php echo $result['op6'] ?>"  id='text_<?php echo $result['id'];?>'/>

<?php
}
if($aid==3 and $category==10){
?>
  <input type="text" name="qid[]"  style="width:100px; height:100px; margin-left:270px; margin-top:30px; text-align:center;" value="<?php echo $result['id'];?>" hidden id='text_<?php echo $result['id'];?>' />
  <input type="text" name="<?php echo $result['id'];?>.opt1"  style="width:50px; height:50px; margin-left:270px; margin-top:30px; text-align:center;" value=""  id='text_<?php echo $result['id'];?>' />
    <input type="text" name="<?php echo $result['id'];?>.opt2" style="width:50px; height:50px; text-align:center;" value="<?php echo $result['opt2'] ?>"  id='text_<?php echo $result['id'];?>' />
      <input type="text" name="<?php echo $result['id'];?>.opt3" style="width:50px; height:50px; text-align:center;" value=""  id='text_<?php echo $result['id'];?>'/>
      <input type="text" name="<?php echo $result['id'];?>.opt4" style="width:50px; height:50px; text-align:center;" value="<?php echo $result['opt4'] ?>"  id='text_<?php echo $result['id'];?>'/>
      <input type="text" name="<?php echo $result['id'];?>.op5" style="width:50px; height:50px; text-align:center;" value=""  id='text_<?php echo $result['id'];?>'/>
      <input type="text" name="<?php echo $result['id'];?>.op6" style="width:50px; height:50px; text-align:center;" value="<?php echo $result['op6'] ?>"  id='text_<?php echo $result['id'];?>'/>
      <input type="text" name="<?php echo $result['id'];?>.op7" style="width:50px; height:50px; text-align:center;" value="<?php echo $result['op7'] ?>"  id='text_<?php echo $result['id'];?>'/>


<?php
}
 ?>
</div>
<br>

<?php
$i++;
//var_dump($i);
//var_dump($j);
if ( ( $remainder < 1 ) || ( $i == $number_question && $remainder == 1 ) ) {
echo "<button  id='".$j."' class='next btn btn-success btn-lg' style='font-size:20px;  color:white; font-size: 1.5vw; font-family:'Metal Mania';' type='submit'>Finish</button>";
echo "</div>";

                }  elseif ( $rowcount > $number_question  ) {
if ( $j == 1 && $i == $number_question ) {
echo "<button id='".$j."' class='next btn btn-success btn-lg' style='margin-left:380px; font-size:20px; color:white; font-size: 1.5vw; font-family:'Metal Mania';' type='button'>Next</button>";

echo "</div>";
$i = 0;
$j++;
} elseif ( $k == $rowcount ) {
echo " <button id='".$j."' class='previous btn btn-success btn-lg'style='margin-left:240px; font-size:20px;  color:white; font-size: 1.5vw; font-family:'Metal Mania';' type='button'>Previous</button>
<button id='".$j."' class='next btn btn-success btn-lg' style='font-size:20px; color:white; font-size: 1.5vw; font-family:'Metal Mania';' type='submit'>Finish</button>";
echo "</div>";
$i = 0;
$j++;
} elseif ( $j > 1 && $i == $number_question ) {
echo "<button id='".$j."' class='previous btn btn-success btn-lg' style='margin-left:240px; font-size:20px; color:white; font-size: 1.5vw; font-family:'Metal Mania';' type='button'>Previous</button>
                   <button id='".$j."' class='next btn btn-success btn-lg'style='font-size:20px;  color:white; font-size: 1.5vw; font-family:'Metal Mania';' type='button' >Next</button>";
echo "</div>";
                  echo "</div>";
$i = 0;
$j++;
}

}
 $k++;
    }
             echo"</div>"?>
</form>

<?php

if(isset($_POST[1])){
   $keys=array_keys($_POST);
   $order=join(",",$keys);
   //var_dump($keys);
   //$query="select * from questions id IN($order) ORDER BY FIELD(id,$order)";
  // echo $query;exit;

  // $response=mysql_query("select id,correct from question where id IN($order) ORDER BY FIELD(id,$order)")   or die(mysql_error());
  $opt1=$_REQUEST['opt1'];
  echo $opt1;
  $opt2=$_POST["opt2"];
  $opt3=$_POST["opt3"];

    $sql="SELECT * FROM question WHERE correct ='$a' ";
    //var_dump($sql);
    $result =mysqli_query($conn,$sql);
    if(mysqli_num_rows($result)==1){
      //$_SESSION["Question"] = $correct;
      echo "<script>alert('Match Successfully');
            window.location.href='que.php';
          </script>";
    }
   $right_answer=0;
   $wrong_answer=0;
   $unanswered=0;
   while($result=mysql_fetch_array($response)){
       if($result['correct']==$_POST[$result['id']]){
               $right_answer++;
               echo $right_answer;
           }else if($_POST[$result['id']]==5){
               $unanswered++;
           }
           else{
               $wrong_answer++;
           }
   }
   echo "right_answer : ". $right_answer."<br>";
   echo "wrong_answer : ". $wrong_answer."<br>";
   echo "unanswered : ". $unanswered."<br>";
}
?>


<script>
$('.cont').addClass('hide');

$('#question_splitter_1').removeClass('hide');

$(document).on('click','.next',function(){
   last=parseInt($(this).attr('id'));  console.log( last );
   nex=last+1;
   $('#question_splitter_'+last).addClass('hide');

   $('#question_splitter_'+nex).removeClass('hide');
});

$(document).on('click','.previous',function(){
   last=parseInt($(this).attr('id'));
   pre=last-1;
   $('#question_splitter_'+last).addClass('hide');

   $('#question_splitter_'+pre).removeClass('hide');
});

         setTimeout(function() {
             $("form").submit();
          }, 120000);
</script>



    <script>
var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.display === "block") {
      content.style.display = "none";
    } else {
      content.style.display = "block";
    }
  });
}
</script>
</body>
</html>
<?php }else{

 //header( 'Location:login.php' ) ;

}
?>
<?php
include('config.php');



 ?>
