<?php
$host       = "localhost";
$dbusername = "phpmyadmin";
$dbpass     = "krutika123";
$dbname     = "quiz2";
$con      = mysqli_connect($host, $dbusername, $dbpass, $dbname);



// if (!$con) {
//     die("Connection failed: " . mysqli_connect_error());
// }
// echo "Connected successfully baby!";

?>
