<?php
session_start();
$servername="localhost";
$username="pratiksha";
$password="Pari@123";
$dbname="SpellingMaker";

$conn=mysqli_connect($servername,$username,$password,$dbname);
 if(!$conn){
die("connection failed:".mysqli_connect_error());
}


 $oldpass=$_POST['password'];
 $newpass=$_POST['pass1'];
 $email=$_SESSION["admin"];
 $sql="SELECT * FROM admin where password='$oldpass' AND email='$email'";
 $result=mysqli_query($conn,$sql);

  if(mysqli_num_rows($result)==1){
  $sqlup="update admin set password='$newpass' where email='$email'";

  if($conn->query($sqlup)==1){
  echo"<script>
alert('password updated successfully.....');
window.location.href='changepassword.php';
</script>";

  }
  else{
    echo"<script>
  alert('something went wrong try again.....');
  window.location.href='index.php? href=updatepassword';
  </script>";
  }
  }
  else{
    echo"<script>
  alert('invalid password entered.....');
  window.location.href='index.php? href=updatepassword';
  </script>";
  }


  ?>
