<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" href="student_image/pratham.jpeg">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </head>
<style media="screen">
footer{
background: linear-gradient(to bottom right, #0099cc 1%, #99ffcc 100%);
}
</style>
  <body>

    <nav class="navbar navbar-light container-fluid sticky-top" style=" background: linear-gradient(to bottom right, #0099cc 1%, #99ffcc 100%);">
      <div class="col-lg-3 col-4">
        <a class="navbar-brand" href="index.php">
          <img src="pra.png" class="img-fluid mb-1" alt="">
        </a>
      </div>
      <div class="col-lg-3 col-5">
          <h1 class="align-bottom pl-2" style="font-size:4vw;font-family: 'Lobster', cursive;color:green">Spelling<span style="font-family: 'Lobster', cursive;color:blue;font-size:4vw;">Maker</span></h1>
      </div>
      <div class="col-lg-2 col-3" >
        <form class="form-colntrol" action="logout.php" method="post">
                <?php
                                  session_start();
                                  error_reporting(0);
                                  if (strlen($_SESSION['admin_id'])>=0) {
                                    echo "<a href='logout.php' class='btn btn-success' style='font-family: Georgia; color:white; font-size:20px;'>Logout</a>";
                                  } else {
                                      echo "<input type='submit' class='btn ' style='background-color:yellowgreen;font-family: 'Metal Mania';' name='logout' value='Logout'>";
                                  }
                                   ?>
                                 </form>
        <!-- <a href="logout.php" class="btn" style="background-color:yellowgreen;font-family: 'Metal Mania';">Logout</a> -->
      </div>

    </nav>


<div style="background:linear-gradient(to bottom, #00ccff 42%, #669900 91%);"><br>
  <center><h1> Add Garde</h1></center>

   <!--Side Nav-->
   <div class="container mt-5">
     <div class="row">
       <div class="col-lg-4">

               <nav class="nav  border border-primary" style="border-radius:8px;background:linear-gradient(to bottom, #00ffff 13%, #99ff99 67%);">

                   <div class="container">
                     <a class="nav-item nav-link text-primary p-4 h4" style="font-weight: bold;" href="dashboard.php"><i class="fa fa-home" aria-hidden="true"></i> &nbsp;Home</a>
                     <a class="nav-item nav-link text-primary p-4 h4" style="font-weight: bold;" href="user.php"><i class="fa fa-users" aria-hidden="true"></i> &nbsp;Users</a>
                     <a class="nav-item nav-link text-primary p-4 h4" style="font-weight: bold;" href="userreport.php"><i class="fa fa-book" aria-hidden="true"></i> &nbsp;User Report</a>


                             <a class="nav-item nav-link text-primary p-4 h4"style="font-weight: bold;" href="agegroup.php"><i class="fa fa-arrow-circle-right" aria-hidden="true"></i> &nbsp;Grade</a>
                             <a class="nav-item nav-link text-primary p-4 h4"style="font-weight: bold;" href="category.php"><i class="fa fa-tasks" aria-hidden="true"></i> &nbsp; Levels</a>

                   <a class="nav-item nav-link text-primary p-4 h4" style="font-weight: bold;" href="questions.php"><i class="fa fa-question-circle" aria-hidden="true"></i> &nbsp;Add Question</a>
                   <a class="nav-item nav-link text-primary p-4 h4" style="font-weight: bold;" href="feedback.php"><i class="fa fa-pencil" aria-hidden="true"></i> &nbsp;Feedback</a>
                   <a class="nav-item nav-link text-primary p-4 h4" style="font-weight: bold;" href="changepassword.php"><i class="fa fa-gear" aria-hidden="true"></i> &nbsp;Change Password</a><br>
                 </div>

               </nav><br>
       </div>




         <div class="col-lg-8 col-12">



             <form class="" action="agegroup_handler.php" method="post">
             <center>  <label class="" style="font-size:20px"><b>Grade</b></label>
               <input type="text" name="grade" class="form-group" ><br><center>

                 <center>  <label class="" style="font-size:20px"><b>Age limit</b></label>
                   <input type="text" name="agelimit" class="form-group" ><br><center>

               <center><input type="submit" name="add" class="form-group" value="Add Age-Group"></center>
             </form><br>

             <?php
             if(isset($_GET['msg'])){
             $mss = $_GET['msg'];
             echo "<center><h4 class='text-success'>$mss</h4></center>";
             }
             ?>
               <table class="table table-bordered">
                 <thead class="thead-light ">
                   <tr>
                     <th scope="col">Sr.No</th>
                     <th scope="col"> Grades&nbsp;</th>
                     <th scope="col"> Description</th>
                     <th scope="col">Operate</th>
                   </tr>
                 </thead>
                 <tbody>
                   <?php
                               $conn=mysqli_connect("localhost","rahul","Rahul@123","quiz2");
                                 $sql="select * from Grade";
                                 $result=mysqli_query($conn,$sql);
                                 $row = mysqli_affected_rows($conn);
                                 if ($result == True) {
                                   $i=1;
                                   while ($record=mysqli_fetch_assoc($result)) {
                                       echo "<tr>";
                                       $id = $record['Grade_id'];

                                       echo "<td>".$i."</td>";
                                       echo "<td>".$record['Grade_id']."</td>";
                                        echo "<td>".$record['Grade_name']."</td>";

                                       echo "<td><a  data-toggle='modal' data-target='#myModal' href='delete_user.php?msg=$id'> <i class='fa fa-trash'></i></a></td>";
                                       echo "</tr>";
                                       $i++;
                                  }
                                 }
                                ?>
                 </tbody>
               </table>


           </div>
         </div>




</div>
     </div>
     <footer class="page-footer font-small blue">

       <!-- Copyright -->
       <div class="footer-copyright text-center py-2">© 2018 Copyright:
         <a href="https://mdbootstrap.com/education/bootstrap/">spellingMaker.com</a>
       </div>
       <!-- Copyright -->

     </footer>


<!--Delete modal-->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">


      <div class="modal-header"style="background-color:skyblue;">

        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>


      <div class="modal-body"style="background-color:lightpink;">

<div class="container ">

        <div class="row">

          <div class="col-lg-12">
            <form class="" action="age_delete_handler.php" method="post">
              <h1>Age Group Delete</h1><br>

              <label for="text">Grade Group:</label>
              <input type="text" class="form-control" name="age" placeholder="age" value=""style="border-radius:10px;"><br>


              <input type="submit" name="age_delete" value="Delete"style="border-radius:10px;">
            </form>
          </div>


      </div>



    </div>
  </div>
</div>

</div>
</div>








  </body>
</html>
