<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

   <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>

   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>




   <style media="screen">

   .artical{background-image:url("image/DSC100399901.jpg");
     width:101vw;
   height:80vh;


   }

   body {
   font-family: 'Metal Mania';font-size: 22px;
   }
   .form{
   background-color:rgba(255,0,255,0.4);
   margin-top:4vh;height:70vh;
   }


   .h{
     font-family: 'Metal Mania';font-size: 30px;   color: #00bacc;


   }
   #head{
     font-family: 'Metal Mania';font-size: 80px;

   }

   </style>





    <title></title>
  </head>
  <body>




    <nav class="navbar navbar-light container-fluid sticky-top" style=" background: linear-gradient(to bottom right, #0099cc 1%, #99ffcc 100%);">
      <div class="col-lg-3 col-4">
        <a class="navbar-brand" href="index.php">
          <img src="pra.png" class="img-fluid mb-1" alt="">
        </a>
      </div>
      <div class="col-lg-3 col-5">
          <h1 class="align-bottom pl-2" style="font-size:4vw;font-family: 'Lobster', cursive;color:green">Spelling<span style="font-family: 'Lobster', cursive;color:blue;font-size:4vw;">Maker</span></h1>
      </div>
      <div class="col-lg-2 col-3" >
        <form class="form-colntrol" action="logout.php" method="post">
                <?php
                                  session_start();
                                  error_reporting(0);
                                  if (strlen($_SESSION['user_id'])>=0) {
                                    echo "<a href='logout.php' class='btn btn-success' style='font-family: Georgia; color:white; font-size:20px;'>Logout</a>";
                                  } else {
                                      echo "<input type='submit' class='btn ' style='background-color:yellowgreen;font-family: 'Metal Mania';' name='logout' value='Logout'>";
                                  }
                                   ?>
                                 </form>
        <!-- <a href="logout.php" class="btn" style="background-color:yellowgreen;font-family: 'Metal Mania';">Logout</a> -->
      </div>

    </nav>









<div style="background:linear-gradient(to bottom, #00ccff 42%, #669900 91%);">
  <br>
<center><h1>Add Question </h1></center>

       <!--Side Nav-->
       <div class="container mt-5">
         <div class="row">
           <div class="col-lg-4">

                   <nav class="nav  border border-primary" style="border-radius:8px;background:linear-gradient(to bottom, #00ffff 13%, #99ff99 67%);">

                       <div class="container">
                         <a class="nav-item nav-link text-primary p-4 h4" style="font-weight: bold;" href="dashboard.php"><i class="fa fa-home" aria-hidden="true"></i> &nbsp;Home</a>
                         <a class="nav-item nav-link text-primary p-4 h4" style="font-weight: bold;" href="user.php"><i class="fa fa-users" aria-hidden="true"></i> &nbsp;Users</a>
                         <a class="nav-item nav-link text-primary p-4 h4" style="font-weight: bold;" href="userreport.php"><i class="fa fa-book" aria-hidden="true"></i> &nbsp;User Report</a>


                                 <a class="nav-item nav-link text-primary p-4 h4"style="font-weight: bold;" href="agegroup.php"><i class="fa fa-arrow-circle-right" aria-hidden="true"></i> &nbsp;Age Group</a>
                                 <a class="nav-item nav-link text-primary p-4 h4"style="font-weight: bold;" href="category.php"><i class="fa fa-tasks" aria-hidden="true"></i> &nbsp; Category</a>

                       <a class="nav-item nav-link text-primary p-4 h4" style="font-weight: bold;" href="questions.php"><i class="fa fa-question-circle" aria-hidden="true"></i> &nbsp;Add Question</a>
                       <a class="nav-item nav-link text-primary p-4 h4" style="font-weight: bold;" href="feedback.php"><i class="fa fa-pencil" aria-hidden="true"></i> &nbsp;Feedback</a>
                       <a class="nav-item nav-link text-primary p-4 h4" style="font-weight: bold;" href="changepassword.php"><i class="fa fa-gear" aria-hidden="true"></i> &nbsp;Change Password</a><br>
                     </div>

                   </nav><br>
           </div>
    <form class="card-body" id="big" action="questions_handler.php" method="post" enctype="multipart/form-data">
            <br><br>
            <center>
              <div class="form-group row">
              <label for=""class="col-lg-3 py-2">Grade</label>
              <select class="form-control col-lg-9" name="grad"  id="category" onchange="getSubcat(this.value);" required>

    <option value="">Select Grade</option>
                <?php
                     $conn = mysqli_connect("localhost","pratiksha","Pari@123","SpellingMaker");
                     $sql = "select *from grade";
                     $res = mysqli_query($conn,$sql);
                     while ($record = mysqli_fetch_assoc($res)) {
                       $id = $record['id'];
                       $name = $record['gname'];
                       echo "<option value='$id'>$name</option>";
                     }
                    ?>
              </select>
            </div>

            <script type="text/javascript">
                 function getSubcat(val) {
                   $.ajax({
                   type: "POST",
                   url: "get_cat.php",
                   data:'id='+val,
                   success: function(data){
                     $("#subcategory").html(data);
                   }
                   });
                   }
                  </script>
                  <div class="form-group row">
                           <label for="" class="col-lg-3 py-2">Levels</label>
                           <select class="form-control col-lg-9" name="lev" id="subcategory">

                           </select>
                         </div>




                   <div class="form-group row">
                             <label class="col-lg-3">Question Name</label>
                             <input type="text" name="qname" value="" class="form-control col-lg-9" placeholder="Enter Your Question">
                           </div>
                           <div class="form-group row">
                             <label class="col-lg-3">image</label>
                             <input type="file" name="file" value="" class="form-control col-lg-9" placeholder="Enter image">
                           </div>
                           <div class="form-group row">
                             <label class="col-lg-3">option 1</label>
                             <input type="text" name="op1" value="" class="form-control col-lg-9" placeholder="Enter first letter">
                           </div>
                           <div class="form-group row">
                             <label class="col-lg-3">Option 2</label>
                             <input type="text" name="op2" value="" class="form-control col-lg-9" placeholder="Enter second letter">
                           </div>

                           <div class="form-group row">
                             <label class="col-lg-3">Option 3</label>
                             <input type="text" name="op3" value="" class="form-control col-lg-9" placeholder="Enter third letter">
                           </div>
                           <div class="form-group row">
                             <label class="col-lg-3">Option 4</label>
                             <input type="text" name="op4" value="" class="form-control col-lg-9" placeholder="Enter fourth letter">
                           </div>
                           <div class="form-group row">
                             <label class="col-lg-3">Option 5</label>
                             <input type="text" name="op5" value="" class="form-control col-lg-9" placeholder="Enter fifth letter">
                           </div>
                           <div class="form-group row">
                             <label class="col-lg-3">Option 6</label>
                             <input type="text" name="op6" value="" class="form-control col-lg-9" placeholder="Enter sixth letter">
                           </div>
                           <div class="form-group row">
                             <label class="col-lg-3">Option 7</label>
                             <input type="text" name="op7" value="" class="form-control col-lg-9" placeholder="Enter seventh letter">
                           </div>
                           <div class="form-group row">
                             <label class="col-lg-3">Correct Answer</label>
                             <input type="text" name="ca" value="" class="form-control col-lg-9" placeholder="Enter Correct Answer">
                           </div>


                         <button type="submit" name="save" class="btn btn-dark text-light">Insert</button><br><br>
                       </center>

          </form>

<?php
if(isset($_GET['msg'])){
  $mss = $_GET['msg'];
  echo "<center><h3 class='text-success'>$mss</h3></center>";
}
 ?>


 <table class="table table-bordered mt-5 table-responsive">
   <thead class="thead-light ">
     <tr>

       <th scope="col"> Sr.No</th>
        <!-- <th scope="col">Question ID</th> -->
       <th scope="col">Grade</th>
       <th scope="col">Levels</th>
       <th scope="col">Question Name</th>
       <th scope="col">Image</th>
       <th scope="col">Option 1</th>
       <th scope="col">Option 2</th>
       <th scope="col">Option 3</th>
       <th scope="col">Option 4</th>
       <th scope="col">Option 5</th>
       <th scope="col">Option 6</th>
       <th scope="col">Option 7</th>
       <th scope="col">Correct Answer</th>



     </tr>
   </thead>
   <tbody>
     <?php
     $conn=mysqli_connect("localhost","pratiksha","Pari@123","SpellingMaker");
       $sql="select * from question";
       $result=mysqli_query($conn,$sql);
       $row = mysqli_affected_rows($conn);
       if ($result == True) {
         $i=1;
         while ($record=mysqli_fetch_assoc($result)) {
             echo "<tr>";
             $id = $record['id'];
             $a=$record['gid'];
             $sql1="select * from grade where id=$a";
             $result1=mysqli_query($conn,$sql1);
             $record1=mysqli_fetch_assoc($result1);
             $id1 = $record1['gname'];

             $b=$record['lid'];
             $sql2="select * from level where lid=$b";
             $result2=mysqli_query($conn,$sql2);
             $record2=mysqli_fetch_assoc($result2);
             $id2 = $record2['level'];
             echo "<td>".$i."</td>";
             //echo"<td>".$id."</td>";
              echo "<td>".$id1."</td>";
             echo "<td>".$id2."</td>";
              echo "<td>'".$record['que_name']."'</td>";
              echo"<td>'".$record['img']."'</td>";
             echo"<td>'".$record['opt1']."'</td>";
              echo"<td>'".$record['opt2']."'</td>";
               echo"<td>'".$record['opt3']."'</td>";
                echo"<td>'".$record['opt4']."'</td>";
                echo"<td>'".$record['op5']."'</td>";
                 echo"<td>'".$record['op6']."'</td>";
                 echo"<td>'".$record['op7']."'</td>";

                 echo"<td>'".$record['correct']."'</td>";

             //echo "<td> <a href='deletecategory.php?msg=$id'> <i class='fa fa-trash'></i></a></td>";
             echo "</tr>";
             $i++;
        }


       }
      ?>
   </tbody>
 </table>




</div>

</div>
<div class="">
  <footer class="bg-secondary text-light text-center"> Copyright 2019 By Pratham InfoTech Foundation</footer>
</div>
</div>



  </body>
</html>
