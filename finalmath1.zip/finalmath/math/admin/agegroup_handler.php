<?php

$conn=mysqli_connect("localhost","rahul","Rahul@123","quiz2");
if(isset($_POST['add'])){
  $name=$_POST['grade'];

  $sql="insert into Grade values(null,'".$name."')";
  echo $sql;
  $result=mysqli_query($conn,$sql);
  if($result){
  header('Location:agegroup.php?msg=Age Group Add Succesfully..');


  }
  else{
    header('Location:agegroup.php?msg=Age group not added');
  }
}
else{


  echo"Error";
}










 ?>
