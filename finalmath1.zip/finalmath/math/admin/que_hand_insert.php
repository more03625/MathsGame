<?php

$conn=mysqli_connect("localhost","pratiksha","Pari@123","SpellingMaker");

if(isset($_POST['save'])){
$age_group=$_POST['age'];
$cname=$_POST['cat'];
$qu1=$_POST['qname'];
$img=$_FILES['img']['name'];
$op1=$_POST['op1'];
$op2=$_POST['op2'];
$op3=$_POST['op3'];
$op4=$_POST['op4'];
$op5=$_POST['op5'];
$op6=$_POST['op6'];
$op7=$_POST['op7'];
$cans=$_POST['ca'];



$query=mysqli_query($conn,"select max(id) as id from question");
$result=mysqli_fetch_array($query);
$qid=$result['id']+1;
$dir="queimg/$qid";
if(!is_dir($dir)){
mkdir("queimg/".$qid,0777);
}
move_uploaded_file($_FILES["op1"]["tmp_name"],"queimg/$qid/".$_FILES["op1"]["name"]);
// move_uploaded_file($_FILES["op2"]["tmp_name"],"queimg/$qid/".$_FILES["op2"]["name"]);
// move_uploaded_file($_FILES["op3"]["tmp_name"],"queimg/$qid/".$_FILES["op3"]["name"]);
// move_uploaded_file($_FILES["op4"]["tmp_name"],"queimg/$qid/".$_FILES["op4"]["name"]);


$sql="insert into question values(null,$age_group,$cname,'$qu1','$op1','$op2','$op3','$op4','$hint',$cans)";

$result1=mysqli_query($conn,$sql);
if($result1){
header('Location:questions.php?msg=Questions added succesfully...');
}
else{

  header('Location:questions.php?msg=question Not added succesfully...');
}

}

else{

echo"error";
}


?>
