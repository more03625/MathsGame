<?php

$conn=mysqli_connect("localhost","root","","quiz");

if (isset($_POST['cate_delete'])) {
  $cat=$_POST['cat'];

  $sql="DELETE from category where category='$cat'";

  $result=mysqli_query($conn,$sql);
if ($result) {
  $message1 = "Category deleted succesfully.";
  echo "<script type='text/javascript'>confirm('$message1');window.location= 'category.php';</script>";

}else {
  $message2 = "Category not deleted.";
  echo "<script type='text/javascript'>alert('$message2');window.location= 'category.php';</script>";

}


}


 ?>
