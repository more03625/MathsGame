<?php

$conn=mysqli_connect("localhost","root","","quiz");

if (isset($_POST['report_delete'])) {

$name=$_POST['name'];

$sql="DELETE from users where user_name='$name'";
$result=mysqli_query($conn,$sql);

if ($result) {
  $message1 = "Report delete succesfully.";
  echo "<script type='text/javascript'>confirm('$message1');window.location= 'userreport.php';</script>";

}else {
  $message2 = "Report Not  deleted .";
  echo "<script type='text/javascript'>alert('$message2');window.location= 'userreport.php';</script>";

}

}






 ?>
