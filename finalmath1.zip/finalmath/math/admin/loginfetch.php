<?php
include 'login.php';
session_start();
$servername = "localhost";
$username = "pratiksha";
$password = "Pari@123";
$dbname = "SpellingMaker";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
die("Connection failed: " . mysqli_connect_error());
}

$email=$_POST["email"];
$password=$_POST["password"];

  $sql="SELECT * FROM admin WHERE email ='$email' AND password ='$password'";
  $result =mysqli_query($conn,$sql);

  if(mysqli_num_rows($result)==1){
    $_SESSION["admin"] = $email;
    echo "<script>alert('Login Successfully');
          window.location.href='dashboard.php';
        </script>";
  }
  else {
    echo "<script>alert('Sorry,Invalid Email and Password');
          window.location.href='login.php';
        </script>";
  }
 ?>
