<?php

$conn=mysqli_connect("localhost","pratiksha","Pari@123","SpellingMaker");

if(isset($_POST['submit'])){
  $grade=$_POST['gname'];
$level=$_POST['cname'];
$desc=$_POST['desc'];


$query=mysqli_query($conn,"select max(lid) as lid from level");
$result=mysqli_fetch_array($query);
$cid=$result['lid']+1;


$sql="insert into level values(null,'$grade','$level','$desc')";
$result1=mysqli_query($conn,$sql);
if($result1){
  header('Location:category.php?msg=Category added succesfully...');
}
else{

    header('Location:category.php?msg=Category Not added succesfully...');
}

}

else{

  echo"error";
}











 ?>
