<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Lobster&display=swap" rel="stylesheet">
    <link rel="icon" href="pra.png">
    <link rel="icon" href="Images/1520320708piflogo.png">
    <style media="screen">
      .a{
        font-family: 'Metal Mania', cursive;color:yellowgreen"
      }

    </style>
  </head>
  <body>

<nav class="navbar navbar-light container-fluid sticky-top" style=" background: linear-gradient(to bottom right, #0099cc 1%, #99ffcc 100%);">
  <div class="col-lg-3 col-4">
    <a class="navbar-brand" href="index.php">
      <img src="pra.png" class="img-fluid mb-1" alt="">
    </a>
  </div>
  <div class="col-lg-3 col-5">
      <h1 class="align-bottom pl-2" style="font-size:4vw;font-family: 'Lobster', cursive;color:green">Spelling<span style="font-family: 'Lobster', cursive;color:blue;font-size:4vw;">Maker</span></h1>
  </div>
  <div class="col-lg-2 col-3" >
    <!-- <form class="form-colntrol" action="logout.php" method="post">
    //  <?php
                             // session_start();
                             //  error_reporting(0);
                             //  if (strlen($_SESSION['user_id'])>=0) {
                             //    echo "<a href='logout.php' class='btn a' style='background-color:yellowgreen;font-family: 'Georgia';'>Logout</a>";
                             //  } else {
                             //      echo "<input type='submit' class='btn ' style='background-color:yellowgreen;font-family: 'Georgia';' name='logout' value='Logout'>";
                             //  }
                               // ?>
                             </form> -->
<!-- <a href="logout.php" class="btn" style="background-color:yellowgreen;font-family: 'Metal Mania';">Logout</a> -->
  </div>

</nav>



<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
